# ViscaBet Betting Platform

Professional, functional and standard betting website source code.

## Instructions
Extract and open `index.html` in any modern web browser.